words = ['apple', 'banana', 'kiwi']
w_lst = [len(w) for w in words]
print(w_lst)