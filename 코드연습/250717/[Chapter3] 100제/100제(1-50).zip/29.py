flags = [True, False, True, True]
print(sum(flags))
