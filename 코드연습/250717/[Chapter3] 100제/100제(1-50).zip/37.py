nums = [1, 2, 3, 4, 5]
lst = list(filter(lambda x : x%2!=0,nums))
print(lst)