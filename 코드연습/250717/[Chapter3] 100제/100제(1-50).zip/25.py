names = ['A','B']
scores = [70,90]
zi = list(zip(names, scores))
print(zi)