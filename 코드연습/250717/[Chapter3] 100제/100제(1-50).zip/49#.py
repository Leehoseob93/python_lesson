scores={'math':80, 'eng':70, 'sci':90}
avg = sum(scores.values())/len(scores)
print(avg)

# 28번에 했던거 또 찾아봄..
# 그냥 dict 값 가져오기.... dict.keys() / dict.values() / dict.items() → list