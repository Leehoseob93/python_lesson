nums = [1,2,3,4,5]
se = set(i**2 for i in nums if i % 2 == 0)
print(se)