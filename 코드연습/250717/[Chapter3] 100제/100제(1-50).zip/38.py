d = {'a':3, 'b':1, 'c':2}
i = sorted(d.items(), key = lambda x : x[1])
print(i)