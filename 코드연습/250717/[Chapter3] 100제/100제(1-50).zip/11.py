nums = [ -5, -3, -1, 7, -2 ]
nums = [n for n in nums if n<-0]
print(nums)
