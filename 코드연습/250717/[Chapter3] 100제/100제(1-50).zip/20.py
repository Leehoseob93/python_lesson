nums = [1, 2, 3, 4, 6]
nums = [w for w in nums if w % 2 == 0]
print(len(nums))