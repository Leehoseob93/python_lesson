nums = [10, 20, 30, 40]
avg = sum(nums) / len(nums)
print(avg)