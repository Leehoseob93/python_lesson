words = [ 'tree', 'hi', 'mountain', 'sum' ]
words = [w for w in words if len(w)>=4]
print(words)