words = ['apple', 'zebra', 'kiwi']
taf = any('z' in w for w in words)
print(taf)