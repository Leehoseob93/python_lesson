words = [ 'dog', 'cat', 'fish' ]
words = [w[0] for w in words]
print(words)