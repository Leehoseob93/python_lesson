nums = [1, 2, 3, 4]
cal = [n**2 if n % 2 == 0 else n**3 for n in nums]
print(cal)

# 짝수는 **2 홀수는 **3을 하는 것으로 추정