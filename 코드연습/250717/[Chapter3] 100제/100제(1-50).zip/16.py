nums = [-1, 0, 1, 2, -2]
fi = list(filter(lambda x: x>=0, nums))
print(fi)