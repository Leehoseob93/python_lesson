nums = [6, 1, 4, 3, 2]
nums = [n for n in nums if n%2==0]
nums.sort()
print(nums)

#sorted([n for n in nums if n % 2 ==0])으로 한 줄 정리 가능.