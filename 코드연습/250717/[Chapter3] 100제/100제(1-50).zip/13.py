words = ['hi', 'hello', 'bye']
print([w.upper() for w in words])