words = ['HI', 'HELLO', 'BYE']
words = [w.lower() for w in words]
print(words)