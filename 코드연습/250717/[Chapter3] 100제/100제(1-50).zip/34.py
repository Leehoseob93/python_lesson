words = ['apple', 'banana', 'kiwi']

dic = {k:len(k) for k in words}
print(dic)