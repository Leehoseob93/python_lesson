words = ['a','b','c']
dic = {v:k for k,v in enumerate(words)}
print(dic)

# enumerate(list) = index, value 순서임.