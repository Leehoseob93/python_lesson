nums = [1,2,3]
ma = list(map(lambda x : x**3, nums))
print(ma)