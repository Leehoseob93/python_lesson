nums = [ 1, 2, 3, 4 ]
nums = [x**2 for x in nums]
print(nums)