nums = [ 1, 2, 3 ]
lst = list(map(lambda x : 2*x, nums))
print(lst)