nums = [ 1, 2, 2, 3, 3, 4 ]
nums = set(nums)
print(list(nums))