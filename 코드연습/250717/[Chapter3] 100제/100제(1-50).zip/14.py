nums = [1, 2, 3]
string = [str(s) for s in nums]
print(string)