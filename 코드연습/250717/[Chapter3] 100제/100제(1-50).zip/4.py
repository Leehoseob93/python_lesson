nums = [ 1, 2, 3 ]
nums = [x+10 for x in nums]
print(nums)