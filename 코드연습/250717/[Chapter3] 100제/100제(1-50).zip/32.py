s = 'HelloPython'
t = set(s.lower())
a = list(dict.fromkeys(t))
print(a)